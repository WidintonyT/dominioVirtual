"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Send,
  Building2
} from "lucide-react";
import { useState } from "react";

export default function ContactoPage() {
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    telefono: "",
    asunto: "",
    mensaje: ""
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aquí iría la lógica para enviar el formulario
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const oficinas = [
    {
      nombre: "Oficina Central",
      direccion: "Av. Principal 123, Edificio Corporativo, Piso 5",
      ciudad: "Ciudad Capital, País",
      telefono: "+1 (555) 123-4567",
      email: "info@dominiovirtual.net"
    },
    {
      nombre: "Oficina Regional Norte",
      direccion: "Calle Norte 456, Centro Empresarial Torre B",
      ciudad: "Ciudad Norte, País",
      telefono: "+1 (555) 234-5678",
      email: "norte@dominiovirtual.net"
    },
    {
      nombre: "Oficina Regional Sur",
      direccion: "Av. Sur 789, Plaza Comercial Local 12",
      ciudad: "Ciudad Sur, País",
      telefono: "+1 (555) 345-6789",
      email: "sur@dominiovirtual.net"
    }
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Badge className="mb-4">Contáctanos</Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Estamos aquí para ayudarte
              </h1>
              <p className="text-xl text-muted-foreground">
                Comunícate con nosotros a través de cualquiera de nuestros canales. Estaremos encantados de atenderte.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Form & Info */}
        <section className="py-12 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Contact Info Cards */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <MapPin className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>Ubicación</CardTitle>
                    <CardDescription>
                      Av. Principal 123, Edificio Corporativo<br />
                      Piso 5, Ciudad Capital<br />
                      Código Postal: 12345
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card>
                  <CardHeader>
                    <Phone className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>Teléfono</CardTitle>
                    <CardDescription>
                      Principal: +1 (555) 123-4567<br />
                      Fax: +1 (555) 123-4568<br />
                      WhatsApp: +1 (555) 123-4569
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card>
                  <CardHeader>
                    <Mail className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>Email</CardTitle>
                    <CardDescription>
                      General: info@dominiovirtual.net<br />
                      Soporte: soporte@dominiovirtual.net<br />
                      Prensa: prensa@dominiovirtual.net
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card>
                  <CardHeader>
                    <Clock className="h-8 w-8 text-primary mb-2" />
                    <CardTitle>Horario</CardTitle>
                    <CardDescription>
                      Lunes a Viernes: 8:00 AM - 6:00 PM<br />
                      Sábados: 9:00 AM - 1:00 PM<br />
                      Domingos: Cerrado
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>

              {/* Contact Form */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">Envíanos un mensaje</CardTitle>
                    <CardDescription>
                      Completa el formulario y nos pondremos en contacto contigo lo antes posible.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="nombre">Nombre completo *</Label>
                          <Input
                            id="nombre"
                            name="nombre"
                            placeholder="Tu nombre"
                            value={formData.nombre}
                            onChange={handleChange}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email *</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            placeholder="tu@email.com"
                            value={formData.email}
                            onChange={handleChange}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="telefono">Teléfono</Label>
                          <Input
                            id="telefono"
                            name="telefono"
                            type="tel"
                            placeholder="+1 (555) 000-0000"
                            value={formData.telefono}
                            onChange={handleChange}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="asunto">Asunto *</Label>
                          <Input
                            id="asunto"
                            name="asunto"
                            placeholder="¿En qué podemos ayudarte?"
                            value={formData.asunto}
                            onChange={handleChange}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="mensaje">Mensaje *</Label>
                        <Textarea
                          id="mensaje"
                          name="mensaje"
                          placeholder="Escribe tu mensaje aquí..."
                          rows={6}
                          value={formData.mensaje}
                          onChange={handleChange}
                          required
                        />
                      </div>

                      <Button type="submit" size="lg" className="w-full md:w-auto">
                        <Send className="mr-2 h-4 w-4" />
                        Enviar Mensaje
                      </Button>

                      {submitted && (
                        <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md">
                          <p className="text-sm text-green-800 dark:text-green-200">
                            ¡Mensaje enviado con éxito! Nos pondremos en contacto contigo pronto.
                          </p>
                        </div>
                      )}
                    </form>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Offices Section */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Nuestras Oficinas</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Contamos con varias ubicaciones para servirte mejor. Visítanos en la oficina más cercana.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {oficinas.map((oficina, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Building2 className="h-10 w-10 text-primary mb-3" />
                    <CardTitle className="text-xl">{oficina.nombre}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <div>
                        <p>{oficina.direccion}</p>
                        <p className="text-muted-foreground">{oficina.ciudad}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${oficina.telefono}`} className="hover:text-primary">
                        {oficina.telefono}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${oficina.email}`} className="hover:text-primary break-all">
                        {oficina.email}
                      </a>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-12 bg-background">
          <div className="container mx-auto px-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Encuéntranos</CardTitle>
                <CardDescription>
                  Oficina Central - Av. Principal 123, Ciudad Capital
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="w-full h-96 bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Mapa de ubicación
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      (Aquí se integraría Google Maps o similar)
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
