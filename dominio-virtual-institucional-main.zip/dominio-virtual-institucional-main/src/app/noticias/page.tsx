import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function NoticiasPage() {
  const noticias = [
    {
      id: 1,
      categoria: "Tecnología",
      titulo: "Dominio Virtual implementa nueva plataforma de servicios digitales",
      resumen: "La organización lanza una innovadora plataforma que mejora la experiencia del usuario y agiliza los procesos institucionales.",
      fecha: "15 de Marzo, 2024",
      tiempo: "5 min lectura",
      imagen: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=400&fit=crop"
    },
    {
      id: 2,
      categoria: "Institucional",
      titulo: "Reconocimiento internacional a nuestra gestión de calidad",
      resumen: "Dominio Virtual recibe certificación ISO 9001 por su excelencia en gestión de procesos y servicios.",
      fecha: "10 de Marzo, 2024",
      tiempo: "4 min lectura",
      imagen: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=400&fit=crop"
    },
    {
      id: 3,
      categoria: "Educación",
      titulo: "Nuevo programa de capacitación para desarrollo profesional",
      resumen: "Lanzamos una serie de cursos y talleres diseñados para fortalecer las competencias de nuestros colaboradores.",
      fecha: "5 de Marzo, 2024",
      tiempo: "3 min lectura",
      imagen: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&h=400&fit=crop"
    },
    {
      id: 4,
      categoria: "Innovación",
      titulo: "Alianza estratégica para impulsar la transformación digital",
      resumen: "Firmamos convenio con organizaciones líderes en tecnología para acelerar nuestros proyectos de innovación.",
      fecha: "1 de Marzo, 2024",
      tiempo: "6 min lectura",
      imagen: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=800&h=400&fit=crop"
    },
    {
      id: 5,
      categoria: "Sostenibilidad",
      titulo: "Dominio Virtual se suma a iniciativas de responsabilidad ambiental",
      resumen: "Implementamos políticas verdes y programas de sostenibilidad para reducir nuestra huella ecológica.",
      fecha: "25 de Febrero, 2024",
      tiempo: "4 min lectura",
      imagen: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&h=400&fit=crop"
    },
    {
      id: 6,
      categoria: "Comunidad",
      titulo: "Programa de responsabilidad social impacta a más de 1000 beneficiarios",
      resumen: "Nuestras iniciativas comunitarias continúan generando impacto positivo en las comunidades que servimos.",
      fecha: "20 de Febrero, 2024",
      tiempo: "5 min lectura",
      imagen: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=800&h=400&fit=crop"
    }
  ];

  const anuncios = [
    {
      titulo: "Mantenimiento programado de sistemas",
      fecha: "18 de Marzo, 2024",
      tipo: "Aviso"
    },
    {
      titulo: "Nueva política de seguridad de la información",
      fecha: "12 de Marzo, 2024",
      tipo: "Importante"
    },
    {
      titulo: "Convocatoria para becas de formación 2024",
      fecha: "8 de Marzo, 2024",
      tipo: "Convocatoria"
    },
    {
      titulo: "Actualización de directorio institucional",
      fecha: "3 de Marzo, 2024",
      tipo: "Aviso"
    }
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Badge className="mb-4">Actualidad</Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Noticias y Anuncios
              </h1>
              <p className="text-xl text-muted-foreground">
                Mantente informado sobre las últimas novedades, eventos y logros de Dominio Virtual.
              </p>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-12">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              <div>
                <h2 className="text-2xl font-bold mb-6">Últimas Noticias</h2>
                <div className="space-y-6">
                  {noticias.map((noticia) => (
                    <Card key={noticia.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="grid md:grid-cols-3 gap-0">
                        <div className="relative h-48 md:h-auto">
                          <Image
                            src={noticia.imagen}
                            alt={noticia.titulo}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <CardHeader>
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="secondary">{noticia.categoria}</Badge>
                            </div>
                            <CardTitle className="text-xl hover:text-primary transition-colors">
                              <Link href={`/noticias/${noticia.id}`}>
                                {noticia.titulo}
                              </Link>
                            </CardTitle>
                            <CardDescription>{noticia.resumen}</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span>{noticia.fecha}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                <span>{noticia.tiempo}</span>
                              </div>
                            </div>
                            <Link 
                              href={`/noticias/${noticia.id}`}
                              className="inline-flex items-center gap-1 text-sm text-primary hover:underline mt-3"
                            >
                              Leer más
                              <ArrowRight className="h-4 w-4" />
                            </Link>
                          </CardContent>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Anuncios */}
              <Card>
                <CardHeader>
                  <CardTitle>Anuncios Importantes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {anuncios.map((anuncio, index) => (
                      <div key={index} className="border-b last:border-b-0 pb-4 last:pb-0">
                        <Badge variant="outline" className="mb-2">
                          {anuncio.tipo}
                        </Badge>
                        <h4 className="font-medium text-sm mb-1">
                          {anuncio.titulo}
                        </h4>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {anuncio.fecha}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Categorías */}
              <Card>
                <CardHeader>
                  <CardTitle>Categorías</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {["Tecnología", "Institucional", "Educación", "Innovación", "Sostenibilidad", "Comunidad"].map((categoria) => (
                      <Link
                        key={categoria}
                        href={`/noticias/categoria/${categoria.toLowerCase()}`}
                        className="block px-3 py-2 rounded-md hover:bg-muted transition-colors text-sm"
                      >
                        {categoria}
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Newsletter */}
              <Card className="bg-primary text-primary-foreground">
                <CardHeader>
                  <CardTitle>Suscríbete</CardTitle>
                  <CardDescription className="text-primary-foreground/80">
                    Recibe las últimas noticias en tu correo
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4 opacity-90">
                    Mantente al día con nuestro boletín mensual.
                  </p>
                  <Link 
                    href="/contacto"
                    className="inline-flex items-center justify-center rounded-md bg-background text-foreground px-4 py-2 text-sm font-medium hover:bg-background/90 transition-colors w-full"
                  >
                    Suscribirme
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
