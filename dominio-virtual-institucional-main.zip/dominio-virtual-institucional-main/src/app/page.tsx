import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Code2, Target, Eye, Users, Briefcase, Award, TrendingUp, Rocket, Smartphone, HeartHandshake } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-20 md:py-32">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
                Desarrollamos <span className="text-primary">Software que Hace Historia</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Desde 2022, somos desarrolladores de software apasionados por crear aplicaciones innovadoras que transforman ideas en soluciones digitales reales.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <Link href="/servicios">Ver Proyectos</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/contacto">Contáctanos</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Sobre Nosotros</h2>
              <p className="text-lg text-muted-foreground">
                Dominio Virtual es un equipo de desarrolladores de software comprometidos con la excelencia tecnológica. Desde 2022, hemos estado creando aplicaciones innovadoras que resuelven problemas reales y marcan la diferencia en la vida de las personas.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <Code2 className="h-10 w-10 text-primary mb-2" />
                  <CardTitle>Nuestra Historia</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Fundados en 2022, hemos desarrollado múltiples aplicaciones exitosas incluyendo RecreApp, PastosTech y AdopMe, haciendo historia con cada proyecto.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Award className="h-10 w-10 text-primary mb-2" />
                  <CardTitle>Innovación</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Cada aplicación que desarrollamos incorpora las últimas tecnologías y mejores prácticas de la industria del software.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <TrendingUp className="h-10 w-10 text-primary mb-2" />
                  <CardTitle>Impacto</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Nuestros proyectos han impactado positivamente a usuarios en diferentes sectores, desde entretenimiento hasta tecnología agrícola y adopción de mascotas.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Featured Projects */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Nuestros Proyectos</h2>
              <p className="text-lg text-muted-foreground">
                Aplicaciones que hemos desarrollado con pasión y dedicación, cada una haciendo historia en su campo.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <Card className="border-2 hover:border-primary transition-colors">
                <CardHeader>
                  <Rocket className="h-12 w-12 text-primary mb-4" />
                  <CardTitle className="text-2xl">RecreApp</CardTitle>
                  <CardDescription className="text-base">
                    Plataforma de recreación y entretenimiento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Una aplicación innovadora diseñada para conectar personas con experiencias recreativas y de entretenimiento, facilitando el descubrimiento de actividades y eventos.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 hover:border-primary transition-colors">
                <CardHeader>
                  <Smartphone className="h-12 w-12 text-primary mb-4" />
                  <CardTitle className="text-2xl">PastosTech</CardTitle>
                  <CardDescription className="text-base">
                    Tecnología para el sector agrícola
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Solución tecnológica especializada en la gestión de pastos y ganadería, ayudando a agricultores a optimizar sus operaciones con herramientas digitales modernas.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 hover:border-primary transition-colors">
                <CardHeader>
                  <HeartHandshake className="h-12 w-12 text-primary mb-4" />
                  <CardTitle className="text-2xl">AdopMe</CardTitle>
                  <CardDescription className="text-base">
                    Facilitando la adopción de mascotas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Plataforma dedicada a conectar mascotas en busca de hogar con familias amorosas, facilitando el proceso de adopción y promoviendo el bienestar animal.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Target className="h-8 w-8 text-primary" />
                  <h2 className="text-3xl font-bold">Nuestra Misión</h2>
                </div>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Desarrollar software de calidad que resuelva problemas reales y mejore la vida de las personas. Nos dedicamos a crear aplicaciones innovadoras con las mejores prácticas de desarrollo.
                </p>
                <p className="text-muted-foreground">
                  Cada línea de código que escribimos está pensada para generar valor, facilitar procesos y contribuir positivamente a la transformación digital de diferentes sectores.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Eye className="h-8 w-8 text-primary" />
                  <h2 className="text-3xl font-bold">Nuestra Visión</h2>
                </div>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Ser reconocidos como desarrolladores de software que marcan la diferencia, creando aplicaciones que no solo funcionan, sino que transforman industrias y mejoran experiencias.
                </p>
                <p className="text-muted-foreground">
                  Aspiramos a seguir haciendo historia con cada proyecto, estableciendo nuevos estándares de calidad en el desarrollo de software y siendo referentes de innovación tecnológica.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Our Approach */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <Users className="h-12 w-12 text-primary mx-auto mb-4" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Nuestro Enfoque</h2>
              <p className="text-lg text-muted-foreground">
                Combinamos tecnología de vanguardia con metodologías ágiles para entregar software excepcional.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <Briefcase className="h-6 w-6 text-primary mb-2" />
                  <CardTitle className="text-lg">Desarrollo Ágil</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Implementamos metodologías ágiles para garantizar entregas iterativas, flexibilidad y adaptación constante a las necesidades del proyecto.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Briefcase className="h-6 w-6 text-primary mb-2" />
                  <CardTitle className="text-lg">Tecnologías Modernas</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Utilizamos las tecnologías más actuales y robustas del mercado para garantizar aplicaciones escalables, seguras y de alto rendimiento.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Briefcase className="h-6 w-6 text-primary mb-2" />
                  <CardTitle className="text-lg">Diseño Centrado en el Usuario</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Cada aplicación se diseña pensando en la experiencia del usuario, con interfaces intuitivas y funcionalidades que realmente importan.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Briefcase className="h-6 w-6 text-primary mb-2" />
                  <CardTitle className="text-lg">Código de Calidad</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Mantenemos altos estándares de calidad en nuestro código, con pruebas exhaustivas, documentación clara y arquitectura sólida.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              ¿Tienes un proyecto en mente?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Trabajemos juntos para convertir tu idea en una aplicación exitosa que haga historia.
            </p>
            <Button size="lg" variant="secondary" asChild>
              <Link href="/contacto">Hablemos de tu Proyecto</Link>
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}