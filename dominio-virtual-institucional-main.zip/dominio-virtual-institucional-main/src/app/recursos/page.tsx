import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, 
  Download, 
  FolderOpen, 
  BookOpen, 
  FileCheck,
  Video,
  Image as ImageIcon,
  FileSpreadsheet
} from "lucide-react";

export default function RecursosPage() {
  const documentos = [
    {
      titulo: "Manual de Identidad Corporativa 2024",
      tipo: "PDF",
      tamaño: "2.5 MB",
      categoria: "Institucional",
      fecha: "Marzo 2024",
      icono: FileText
    },
    {
      titulo: "Reglamento Interno Actualizado",
      tipo: "PDF",
      tamaño: "1.8 MB",
      categoria: "Legal",
      fecha: "Febrero 2024",
      icono: FileCheck
    },
    {
      titulo: "Plan Estratégico 2024-2028",
      tipo: "PDF",
      tamaño: "3.2 MB",
      categoria: "Planeación",
      fecha: "Enero 2024",
      icono: FileText
    },
    {
      titulo: "Guía de Buenas Prácticas",
      tipo: "PDF",
      tamaño: "1.5 MB",
      categoria: "Capacitación",
      fecha: "Marzo 2024",
      icono: BookOpen
    }
  ];

  const plantillas = [
    {
      titulo: "Plantilla de Informe Ejecutivo",
      tipo: "DOCX",
      tamaño: "450 KB",
      descripcion: "Formato estándar para informes ejecutivos",
      icono: FileText
    },
    {
      titulo: "Formato de Solicitud de Recursos",
      tipo: "XLSX",
      tamaño: "320 KB",
      descripcion: "Plantilla para solicitudes departamentales",
      icono: FileSpreadsheet
    },
    {
      titulo: "Presentación Institucional",
      tipo: "PPTX",
      tamaño: "5.2 MB",
      descripcion: "Presentación corporativa oficial",
      icono: FileText
    },
    {
      titulo: "Formato de Evaluación de Desempeño",
      tipo: "XLSX",
      tamaño: "280 KB",
      descripcion: "Herramienta de evaluación de personal",
      icono: FileSpreadsheet
    }
  ];

  const multimedia = [
    {
      titulo: "Video Institucional 2024",
      tipo: "MP4",
      tamaño: "45 MB",
      duracion: "5:30 min",
      icono: Video
    },
    {
      titulo: "Galería de Imágenes Corporativas",
      tipo: "ZIP",
      tamaño: "125 MB",
      descripcion: "Banco de imágenes institucionales",
      icono: ImageIcon
    },
    {
      titulo: "Webinar: Transformación Digital",
      tipo: "MP4",
      tamaño: "380 MB",
      duracion: "45:00 min",
      icono: Video
    }
  ];

  const manuales = [
    {
      titulo: "Manual de Usuario - Sistema de Gestión",
      version: "v3.2",
      paginas: "85 páginas",
      categoria: "Tecnología"
    },
    {
      titulo: "Manual de Procedimientos Administrativos",
      version: "v2.1",
      paginas: "120 páginas",
      categoria: "Administración"
    },
    {
      titulo: "Guía de Seguridad de la Información",
      version: "v1.5",
      paginas: "45 páginas",
      categoria: "Seguridad"
    },
    {
      titulo: "Manual de Atención al Usuario",
      version: "v4.0",
      paginas: "65 páginas",
      categoria: "Servicio"
    }
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Badge className="mb-4">Centro de Recursos</Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Recursos y Documentación
              </h1>
              <p className="text-xl text-muted-foreground">
                Accede a documentos institucionales, plantillas, guías y material multimedia de Dominio Virtual.
              </p>
            </div>
          </div>
        </section>

        {/* Resources Section */}
        <section className="py-12 bg-background">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="documentos" className="w-full">
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-8">
                <TabsTrigger value="documentos">Documentos</TabsTrigger>
                <TabsTrigger value="plantillas">Plantillas</TabsTrigger>
                <TabsTrigger value="manuales">Manuales</TabsTrigger>
                <TabsTrigger value="multimedia">Multimedia</TabsTrigger>
              </TabsList>

              {/* Documentos Tab */}
              <TabsContent value="documentos" className="space-y-4">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold mb-2">Documentos Institucionales</h2>
                  <p className="text-muted-foreground">
                    Accede a los documentos oficiales y material normativo de la organización.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {documentos.map((doc, index) => {
                    const Icon = doc.icono;
                    return (
                      <Card key={index} className="hover:shadow-md transition-shadow">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <Icon className="h-10 w-10 text-primary" />
                            <Badge variant="secondary">{doc.tipo}</Badge>
                          </div>
                          <CardTitle className="text-lg mt-3">{doc.titulo}</CardTitle>
                          <CardDescription>
                            <div className="flex items-center gap-4 text-sm mt-2">
                              <span>{doc.tamaño}</span>
                              <span>•</span>
                              <span>{doc.categoria}</span>
                              <span>•</span>
                              <span>{doc.fecha}</span>
                            </div>
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Button variant="outline" className="w-full" size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              {/* Plantillas Tab */}
              <TabsContent value="plantillas" className="space-y-4">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold mb-2">Plantillas y Formatos</h2>
                  <p className="text-muted-foreground">
                    Descarga plantillas estandarizadas para diversos procesos institucionales.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {plantillas.map((plantilla, index) => {
                    const Icon = plantilla.icono;
                    return (
                      <Card key={index} className="hover:shadow-md transition-shadow">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <Icon className="h-10 w-10 text-primary" />
                            <Badge variant="secondary">{plantilla.tipo}</Badge>
                          </div>
                          <CardTitle className="text-lg mt-3">{plantilla.titulo}</CardTitle>
                          <CardDescription>
                            <p className="mt-2">{plantilla.descripcion}</p>
                            <p className="text-sm mt-2">{plantilla.tamaño}</p>
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Button variant="outline" className="w-full" size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              {/* Manuales Tab */}
              <TabsContent value="manuales" className="space-y-4">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold mb-2">Manuales y Guías</h2>
                  <p className="text-muted-foreground">
                    Consulta los manuales operativos y guías de procedimientos institucionales.
                  </p>
                </div>
                <div className="space-y-4">
                  {manuales.map((manual, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <BookOpen className="h-10 w-10 text-primary flex-shrink-0" />
                            <div>
                              <CardTitle className="text-lg">{manual.titulo}</CardTitle>
                              <CardDescription className="mt-2">
                                <div className="flex items-center gap-4 text-sm">
                                  <Badge variant="outline">{manual.version}</Badge>
                                  <span>{manual.paginas}</span>
                                  <span>•</span>
                                  <span>{manual.categoria}</span>
                                </div>
                              </CardDescription>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar
                          </Button>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Multimedia Tab */}
              <TabsContent value="multimedia" className="space-y-4">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold mb-2">Material Multimedia</h2>
                  <p className="text-muted-foreground">
                    Videos institucionales, webinars y recursos visuales corporativos.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {multimedia.map((item, index) => {
                    const Icon = item.icono;
                    return (
                      <Card key={index} className="hover:shadow-md transition-shadow">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <Icon className="h-10 w-10 text-primary" />
                            <Badge variant="secondary">{item.tipo}</Badge>
                          </div>
                          <CardTitle className="text-lg mt-3">{item.titulo}</CardTitle>
                          <CardDescription>
                            <div className="flex items-center gap-3 text-sm mt-2">
                              <span>{item.tamaño}</span>
                              {item.duracion && (
                                <>
                                  <span>•</span>
                                  <span>{item.duracion}</span>
                                </>
                              )}
                            </div>
                            {item.descripcion && (
                              <p className="mt-2">{item.descripcion}</p>
                            )}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Button variant="outline" className="w-full" size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>
            </Tabs>

            {/* Help Section */}
            <Card className="mt-12 bg-muted/30">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <FolderOpen className="h-8 w-8 text-primary" />
                  <div>
                    <CardTitle>¿No encuentras lo que buscas?</CardTitle>
                    <CardDescription className="mt-1">
                      Contáctanos y te ayudaremos a encontrar el recurso que necesitas.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <a href="/contacto">Solicitar Recurso</a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
