import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Rocket, 
  Smartphone, 
  HeartHandshake, 
  Code2, 
  Palette,
  Database,
  Cloud,
  Zap,
  Users2,
  Settings
} from "lucide-react";
import Link from "next/link";

export default function ServiciosPage() {
  const proyectos = [
    {
      icon: Rocket,
      title: "RecreApp",
      categoria: "Entretenimiento & Recreación",
      description: "Plataforma innovadora para conectar personas con experiencias recreativas y de entretenimiento. Facilita el descubrimiento de actividades, eventos y lugares de interés.",
      features: [
        "Sistema de búsqueda avanzada de actividades",
        "Reservas y gestión de eventos",
        "Perfiles de usuario personalizados",
        "Sistema de reseñas y valoraciones"
      ],
      tecnologias: ["React Native", "Node.js", "MongoDB", "AWS"],
      estado: "Activo",
      anio: "2022"
    },
    {
      icon: Smartphone,
      title: "PastosTech",
      categoria: "AgriTech",
      description: "Solución tecnológica especializada en la gestión de pastos y ganadería. Ayuda a agricultores a optimizar sus operaciones mediante herramientas digitales modernas.",
      features: [
        "Monitoreo de condiciones de pastoreo",
        "Gestión de inventario de ganado",
        "Análisis predictivo de producción",
        "Reportes y estadísticas detalladas"
      ],
      tecnologias: ["Flutter", "Firebase", "Python", "TensorFlow"],
      estado: "Activo",
      anio: "2023"
    },
    {
      icon: HeartHandshake,
      title: "AdopMe",
      categoria: "Social Impact",
      description: "Plataforma dedicada a conectar mascotas en busca de hogar con familias amorosas. Facilita el proceso de adopción y promueve el bienestar animal.",
      features: [
        "Perfiles detallados de mascotas",
        "Sistema de matching inteligente",
        "Proceso de adopción guiado",
        "Seguimiento post-adopción"
      ],
      tecnologias: ["Next.js", "PostgreSQL", "Stripe", "Vercel"],
      estado: "Activo",
      anio: "2023"
    }
  ];

  const servicios = [
    {
      icon: Code2,
      title: "Desarrollo de Aplicaciones Móviles",
      description: "Creamos aplicaciones nativas e híbridas para iOS y Android con interfaces intuitivas y rendimiento óptimo."
    },
    {
      icon: Palette,
      title: "Desarrollo Web",
      description: "Diseñamos y desarrollamos sitios web y aplicaciones web progresivas responsivas y modernas."
    },
    {
      icon: Database,
      title: "Backend & APIs",
      description: "Arquitecturas escalables, APIs REST/GraphQL y gestión de bases de datos robustas."
    },
    {
      icon: Cloud,
      title: "Cloud & DevOps",
      description: "Implementación en la nube, CI/CD, contenedores y gestión de infraestructura como código."
    },
    {
      icon: Zap,
      title: "Consultoría Tecnológica",
      description: "Asesoramiento en arquitectura de software, selección de tecnologías y mejores prácticas."
    },
    {
      icon: Settings,
      title: "Mantenimiento & Soporte",
      description: "Mantenimiento continuo, actualizaciones de seguridad y soporte técnico especializado."
    }
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Badge className="mb-4">Nuestro Portfolio</Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Proyectos que Hacen Historia
              </h1>
              <p className="text-xl text-muted-foreground">
                Descubre las aplicaciones que hemos desarrollado y los servicios tecnológicos que ofrecemos para impulsar tu próximo proyecto.
              </p>
            </div>
          </div>
        </section>

        {/* Featured Projects */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="mb-12">
              <h2 className="text-3xl font-bold mb-3">Aplicaciones Desarrolladas</h2>
              <p className="text-muted-foreground">
                Cada proyecto representa nuestro compromiso con la innovación y la calidad en el desarrollo de software.
              </p>
            </div>

            <div className="space-y-8">
              {proyectos.map((proyecto, index) => {
                const Icon = proyecto.icon;
                return (
                  <Card key={index} className="border-2 hover:border-primary transition-all hover:shadow-xl">
                    <div className="grid md:grid-cols-3 gap-6 p-6">
                      <div className="md:col-span-2 space-y-4">
                        <div className="flex items-start gap-4">
                          <div className="p-3 bg-primary/10 rounded-lg">
                            <Icon className="h-8 w-8 text-primary" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-2xl font-bold">{proyecto.title}</h3>
                              <Badge variant="secondary">{proyecto.anio}</Badge>
                              <Badge variant="outline" className="bg-green-500/10 text-green-700 dark:text-green-400">
                                {proyecto.estado}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">{proyecto.categoria}</p>
                            <p className="text-muted-foreground leading-relaxed">
                              {proyecto.description}
                            </p>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Características principales:</h4>
                          <ul className="grid md:grid-cols-2 gap-2">
                            {proyecto.features.map((feature, idx) => (
                              <li key={idx} className="text-sm text-muted-foreground flex items-start">
                                <span className="text-primary mr-2">✓</span>
                                <span>{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-3 text-sm">Stack Tecnológico:</h4>
                          <div className="flex flex-wrap gap-2">
                            {proyecto.tecnologias.map((tech, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="mb-12">
              <h2 className="text-3xl font-bold mb-3">Servicios de Desarrollo</h2>
              <p className="text-muted-foreground">
                Ofrecemos una gama completa de servicios de desarrollo de software para llevar tu proyecto al siguiente nivel.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {servicios.map((servicio, index) => {
                const Icon = servicio.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <Icon className="h-10 w-10 text-primary mb-3" />
                      <CardTitle className="text-xl">{servicio.title}</CardTitle>
                      <CardDescription>
                        {servicio.description}
                      </CardDescription>
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-4">
                ¿Tienes un proyecto en mente?
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Hablemos sobre cómo podemos ayudarte a convertir tu idea en una aplicación exitosa.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild>
                  <Link href="/contacto">Contactar para Proyecto</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/recursos">Ver Más Recursos</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}