import Link from "next/link";
import { Mail, Phone, MapPin, Code2 } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full border-t bg-muted/50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Code2 className="h-5 w-5 text-primary" />
              <h3 className="font-bold text-lg">Dominio Virtual</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Desarrolladores de software apasionados por crear aplicaciones que hacen historia desde 2022.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Inicio
                </Link>
              </li>
              <li>
                <Link href="/servicios" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Proyectos
                </Link>
              </li>
              <li>
                <Link href="/noticias" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Noticias
                </Link>
              </li>
              <li>
                <Link href="/recursos" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Recursos
                </Link>
              </li>
            </ul>
          </div>

          {/* Projects */}
          <div>
            <h3 className="font-bold text-lg mb-4">Proyectos</h3>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground">RecreApp</li>
              <li className="text-sm text-muted-foreground">PastosTech</li>
              <li className="text-sm text-muted-foreground">AdopMe</li>
              <li className="text-sm text-muted-foreground">Desarrollo a Medida</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contacto</h3>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>contacto@dominiovirtual.net</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>Desarrollo Remoto</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Dominio Virtual. Todos los derechos reservados. Haciendo historia desde 2022.
          </p>
        </div>
      </div>
    </footer>
  );
}